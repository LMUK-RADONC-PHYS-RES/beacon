import napari
from napari._qt.layer_controls.qt_shapes_controls import QtShapesControls
from napari.utils.action_manager import action_manager
from packaging.version import Version


class CustomQtLinePromptControls(QtShapesControls):
    """Custom Qt controls for LinePromptLayer, exposing only Line drawing.

    Args:
        layer (LinePromptLayer): The shapes layer associated with this control panel.
    """

    def __init__(self, layer):
        super().__init__(layer)

        if Version(napari.__version__) >= Version("0.6.5"):
            fields_to_hide = [
                self._face_color_control.face_color_edit,
                #self._edge_color_control.edge_color_edit,
                self._text_visibility_control.text_disp_checkbox,
                self._face_color_control.face_color_label,
                #self._edge_color_control.edge_color_label,
                self._text_visibility_control.text_disp_label
            ]
            for field in fields_to_hide:
                field.hide()
                field.setDisabled(True)
        else:
            fields_to_hide = [self.faceColorEdit]#, self.edgeColorEdit]
            for field in fields_to_hide:
                label_item = self.layout().labelForField(field)
                field.hide()
                label_item.hide()
                field.setDisabled(True)

        buttons_to_hide = [
            {"button": self.ellipse_button, "shortcut": "napari:activate_add_ellipse_mode"},
            {"button": self.polygon_button, "shortcut": "napari:activate_add_polygon_mode"},
            {"button": self.polygon_lasso_button, "shortcut": "napari:activate_add_polygon_lasso_mode"},
            {"button": self.rectangle_button, "shortcut": "napari:activate_add_rectangle_mode"},
            {"button": self.path_button, "shortcut": "napari:activate_add_path_mode"},
            {"button": self.polyline_button, "shortcut": "napari:activate_add_polyline_mode"},
            {"button": self.vertex_insert_button, "shortcut": "napari:activate_vertex_insert_mode"},
            {"button": self.vertex_remove_button, "shortcut": "napari:activate_vertex_remove_mode"},
            {"button": self.move_front_button, "shortcut": "napari:move_shapes_selection_to_front"},
            {"button": self.move_back_button, "shortcut": "napari:move_shapes_selection_to_back"},
            {"button": self.transform_button, "shortcut": "napari:activate_shapes_transform_mode"},
            {"button": self.direct_button, "shortcut": "napari:activate_direct_mode"},
        ]

        for button in buttons_to_hide:
            button["button"].setDisabled(True)
            button["button"].hide()
            action_manager.unbind_shortcut(button["shortcut"])

        self.button_grid.addWidget(self.delete_button, 0, 1)
        self.button_grid.addWidget(self.line_button, 0, 2)

        self.line_button.setChecked(True)
